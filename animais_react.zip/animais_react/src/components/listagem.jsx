import React from 'react';

function Listagem({ listaAnimais, concluirAnimal, removerAnimal }) {
  return (
    <>
      {listaAnimais.map((animal) => (
        <div className="animal-card" key={animal.id}>
          <img src={animal.foto} alt={`Foto do animal ${animal.id}`} />
          <h3 style={{ textDecoration: animal.isConcluido ? 'line-through' : '' }}>
            {animal.raca}
          </h3>
          <p>{animal.local}</p>
          <p>{animal.tipo === 'perdido' ? 'Perdido' : 'Resgatado'}</p>
          <div>
            <button className="bt_concluido" onClick={() => concluirAnimal(animal.id)}>
              Já Resgatado/Encontrado
            </button>
            <button className="bt_remover" onClick={() => removerAnimal(animal.id)}>
              Remover Animal
            </button>
          </div>
        </div>
      ))}
    </>
  );
}

export default Listagem;
