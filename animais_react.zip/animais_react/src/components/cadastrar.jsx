import React, { useState } from 'react';

function Cadastrar({ addAnimal }) {
  const [foto, setFoto] = useState('');
  const [raca, setRaca] = useState('');
  const [local, setLocal] = useState('');
  const [tipo, setTipo] = useState('');

  const cadastrar = () => {
    if (foto === '' || raca === '' || local === '' || tipo === '') return;

    addAnimal(foto, raca, local, tipo);

    // Limpar os campos após o cadastro
    setFoto('');
    setRaca('');
    setLocal('');
    setTipo('');
  };

  return (
    <>
      <h2>Cadastro de animais</h2>
      <div className="cadastrar">
        <input
          type="text"
          value={foto}
          onChange={(e) => setFoto(e.target.value)}
          placeholder="Foto do animal"
        />
        <input
          type="text"
          value={raca}
          onChange={(e) => setRaca(e.target.value)}
          placeholder="Raça do animal"
        />
        <input
          type="text"
          value={local}
          onChange={(e) => setLocal(e.target.value)}
          placeholder="Localização (encontrado/perdido)"
        />

        <select value={tipo} onChange={(e) => setTipo(e.target.value)}>
          <option value="" disabled>
            Perdido ou Resgatado
          </option>
          <option value="perdido">Perdido</option>
          <option value="resgatado">Resgatado</option>
        </select>

        <button className="bt_cadastrar" onClick={cadastrar}>
          Cadastrar Animal
        </button>
      </div>
    </>
  );
}

export default Cadastrar;
