import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import Cadastrar from './components/cadastrar';
import Listagem from './components/listagem';
import './app.css';

function App() {
  const [listaAnimais, setListaAnimais] = useState([]);

  const addAnimal = (foto, raca, local, tipo) => {
    const newListaAnimais = [
      ...listaAnimais,
      { id: Math.floor(Math.random() * 100000), foto, raca, local, tipo, isConcluido: false },
    ];

    setListaAnimais(newListaAnimais);
  };

  const concluirAnimal = (id) => {
    const newListaAnimais = listaAnimais.map((animal) =>
      animal.id === id ? { ...animal, isConcluido: !animal.isConcluido } : animal
    );

    setListaAnimais(newListaAnimais);
  };

  const removerAnimal = (id) => {
    const newListaAnimais = listaAnimais.filter((animal) => animal.id !== id);
    setListaAnimais(newListaAnimais);
  };

  return (
    <div className="app">
      <Cadastrar addAnimal={addAnimal} />
      <div className='listagem'>
      <Listagem listaAnimais={listaAnimais} concluirAnimal={concluirAnimal} removerAnimal={removerAnimal} />
      </div>
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));
